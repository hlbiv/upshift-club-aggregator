# Upshift League Seed Pack

This starter pack is designed to seed a canonical youth-soccer club graph. It is **not** a scraped club dump; it is the league/source inventory you should use to pull clubs.

## Files
- `leagues_master.csv` — league inventory with priority, family, gender, and source hints
- `league_sources_seed.csv` — official source registry for scraping
- `usys_state_associations_seed.csv` — the official 54 US Youth Soccer member associations
- `canonical_schema.sql` — normalized Postgres schema for canonical clubs + affiliations

## How to use
1. Load `leagues_master.csv`
2. Crawl rows where `has_public_clubs = true`
3. Store club names in `canonical_clubs`
4. Store league memberships in `club_affiliations`
5. Use `club_aliases` to dedupe variants like:
   - `TopHat`
   - `TopHat SC`
   - `Tophat Soccer Club`

## Priority order
1. MLS NEXT
2. ECNL / ECNL RL / Pre-ECNL
3. Girls Academy / GA Aspire
4. DPL
5. NPL
6. USYS National League
7. State-association hubs
8. Regional power leagues (EDP, SCCL, CCL, SOCAL, NorCal, etc.)

## Important 2026 note
US Club Soccer and US Youth Soccer announced a new top team-based competition for 2026-27 that will bring together the NPL and National League. Keep both current source families in your database until the new competition structure is fully published and club/operator lists stabilize.